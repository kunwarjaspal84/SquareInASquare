var x =0;
var y=0;
var transx =1;
var transy =1;
var interval = null;

var color1 = ["Blue","Green","Yellow","Red","Brown","Black"];
var currentposition = 1;

function startx()
{
	
	clearInterval(interval);
	interval = setInterval(changex,10);
}
function starty()
{
	
	clearInterval(interval);
	interval = setInterval(changey,10);
}
function changex()
{
	currentposition = 1;
	x= x+transx;
	if(x >906)
	{
		x = 905;
		transx = transx * -1;

		document.getElementById("inner").style.left = x +"px";
		document.getElementById("inner").style.background = color1[Math.floor(Math.random()*6)];
		starty();
	}
	else if(x==-1)
	{
		x=5;
		transx = transx *-1;
		document.getElementById("inner").style.left = x +"px";
		document.getElementById("inner").style.background = color1[Math.floor(Math.random()*6)];
		starty();
	}
	
	else
	{
		document.getElementById("inner").style.left = x +"px";
	}
}
function changey()
{
	currentposition = 0;
	y = y+ transy;
	if(y >906)
	{
		y = 905;
		transy = transy * -1;

		document.getElementById("inner").style.top = y +"px";
		document.getElementById("inner").style.background = color1[Math.floor(Math.random()*6)];
		startx();
	}
	else if(y==-1)
	{
		y=5;
		transy = transy *-1;
		document.getElementById("inner").style.top = y +"px";
		document.getElementById("inner").style.background = color1[Math.floor(Math.random()*6)];
		
		startx();
	}
	else
	{
		document.getElementById("inner").style.top = y +"px";
	}
	

}
function pause()
{
	clearInterval(interval);
}
function resume()
{
	clearInterval(interval);
	if(currentposition == 1)
	{
		interval =setInterval(startx,10);
	}
	if(currentposition == 0 )
	{
		interval = setInterval(starty,10);
	}
}
function direction(){
	clearInterval(interval);
	if(currentposition ==1)
	{
		transx = transx *-1;
		interval =setInterval(startx,10);
	}
	if(currentposition == 0)
	{
		transy = transy * -1;
		interval = setInterval(starty,10);
	}
}
function checkposition()
{
	if(x==5 && y==5)
	{
		clearInterval(interval);
		setTimeout(startx(),2000);
	}
}